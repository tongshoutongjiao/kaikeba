$(function() {


    $(".content").height($(window).height());
    $.stellar({
        horizontalScrolling: false,
        responsive: true
    });




    // 头部效果


});